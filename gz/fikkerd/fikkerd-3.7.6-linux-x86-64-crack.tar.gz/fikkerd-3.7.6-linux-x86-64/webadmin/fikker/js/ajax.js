﻿function AjaxPost(AjaxMode,postURL,postStr,returnOBJ,ifLoadImg,Loadimg,Loadmsg){
	var ajax = false;
	var IfchkTimeOut=true;
	var ifdebug=false;

	if(typeof(returnOBJ) == "undefined"){
		needRe=0;
	}else{
		returnOBJ=document.getElementById(returnOBJ); 
		needRe=1;
	}

	if(typeof(Loadimg) == "undefined")var Loadimg="S";
	if(typeof(Loadmsg) == "undefined")var Loadmsg="正在处理，请稍候...";
	if(typeof(ifLoadImg) == "undefined")var ifLoadImg=0;

	function ontimeout(){ 
		if(IfchkTimeOut==true){
			ajax.abort();
			//if(needRe==0)alert("连接超时");
			if(needRe==1){
				var strurl=postURL + "?" + postStr + "&sid=" + Math.random();
				returnOBJ.innerHTML = "连接超时，<a href=" + strurl + " target=_blank>请点此查看</a>";
			}
		}
	}

	if(window.XMLHttpRequest) { //Mozilla 浏览器
		ajax = new XMLHttpRequest();
		if (ajax.overrideMimeType) {//设置MiME类别
			ajax.overrideMimeType("text/plain");
		}
	}
	else if (window.ActiveXObject) { // IE浏览器
		try {
			ajax = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				ajax = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}

	if (!ajax) { // 异常，创建对象实例失败
		window.alert("不能创建XMLHttpRequest对象实例.");
	}

	if(AjaxMode=="POST"){
		if(ifLoadImg==1)returnOBJ.innerHTML="<img src=/Image/Loading" + Loadimg + ".gif> " + Loadmsg;
		ajax.open("POST",postURL,true); 
		setTimeout(ontimeout,5000);
		//ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); 
		ajax.send(postStr);
	}else{
		if(ifLoadImg==1)returnOBJ.innerHTML="<img src=/Image/Loading" + Loadimg + ".gif> " + Loadmsg;
		var strurl=postURL + "?" + postStr + "&sid=" + Math.random();
		setTimeout(ontimeout,5000);//判断连接超时
		ajax.open("GET",strurl,true);
		ajax.send(null);
	}
	//alert(postURL.indexOf("instantrequest"));
	ajax.onreadystatechange = function() { //获取执行状态
	//alert("ajax.readyState:"+ajax.readyState);
	//alert("IfchkTimeOut:"+IfchkTimeOut);
	//if(ajax.readyState == 4)IfchkTimeOut=false;
	//alert("ajax.readyState:"+ajax.readyState);
	if ((ajax.readyState == 4 && ajax.status == 200) || (ajax.readyState == 4 && ajax.status == 0)){
			IfchkTimeOut=false;
			var data=ajax.responseText;
			if(ifdebug==true)alert(data);
//alert(data);
			var data=eval("("+ajax.responseText+")");
			//alert(ajax.responseText);
			var RequestID=data.RequestID;
			//alert(RequestID);
			switch(RequestID){
				case "LOGIN":						//登录验证
					chkLogin(data);
					break;
				case "realtime-list":				//实时监控-列表
					realtimelist(data);
					break;
				case "realtime-totalstat":			//实时监控-获取实时总量统计报告
					realtimetotalstat(data);
					break;
				case "realtime-itemstat":			//实时监控-获取实时分量统计报告
					realtimeitemstat(data);
					break;
				case "system-list":					//系统设置-获取系统配置
					systemlist(data);
					break;
				case "system-modi":					//系统设置-修改当前系统配置
					systemodi(data);
					break;proxy-list
				case "proxy-list":					//主机管理-主机列表
					proxylist(data);
					break;
				case "proxy-del":					//主机管理-删除主机
					proxydel(data);
					break;
				case "proxy-add":					//主机管理-添加主机
					proxyadd(data);
					break;
				case "proxy-getset":				//主机管理-获取主机详细配置
					proxyviewset(data);
					break;
				case "proxy-modi":					//主机管理-修改主机配置
					proxymodi(data);
					break;
				case "upstream-add":				//源站管理-添加源站
					upstreamadd(data);
					break;
				case "upstream-del":				//源站管理-删除源站
					upstreamdel(data);
					break;
				case "upstream-getset":				//源站管理-获取源站详细配置
					upstreamviewset(data);
					break;
				case "upstream-modi":				//源站管理-修改源站配置
					upstreamodi(data);
					break;
				case "protect-list":				//防盗链管理-保护链列表
					protectlist(data);
					break;
				case "protect-add":					//防盗链管理-添加保护链
					protectadd(data);
					break;
				case "protect-getset":				//防盗链管理-获取保护链详细配置
					protectviewset(data);
					break;
				case "protect-modi":				//防盗链管理-修改保护链详细配置
					protectmodi(data);
					break
				case "protect-del":					//防盗链管理-删除保护链
					protectdel(data);
					break;
				case "permit-add":					//防盗链管理-添加引用链
					permitadd(data);
					break;
				case "permit-getset":				//防盗链管理-获取引用链详细配置
					permitviewset(data);
					break;
				case "permit-modi":					//防盗链管理-修改引用链详细配置
					permitmodi(data);
					break;
				case "permit-del":					//防盗链管理-删除引用链
					permitdel(data);
					break;
				case "black-list":					//黑名单管理-黑名单列表
					blacklist(data);
					break;
				case "black-add":					//黑名单管理-添加黑名单
					blackadd(data);
					break;
				case "black-getset":				//黑名单管理-获取黑名单详细配置
					blackviewset(data);
					break;
				case "black-modi":					//黑名单管理-修改黑名单详细配置
					blackmodi(data);
					break
				case "black-del":					//黑名单管理-删除黑名单
					blackdel(data);
					break;
				case "stat-list":					//分量统计管理-分量统计列表
					statlist(data);
					break;
				case "stat-add":					//分量统计管理-添加分量统计
					statadd(data);
					break;
				case "stat-getset":					//分量统计管理-获取分量统计详细配置
					statviewset(data);
					break;
				case "stat-modi":					//分量统计管理-修改分量统计详细配置
					statmodi(data);
					break
				case "stat-del":					//分量统计管理-删除分量统计
					statdel(data);
					break;
				case "stat-up":						//分量统计管理-上移
					statup(data);
					break;
				case "stat-down":					//分量统计管理-下移
					statdown(data);
					break;
				case "rewrite-list":				//转向管理-转向管理列表
					rewritelist(data);
					break;
				case "rewrite-add":					//转向管理-添加转向管理
					rewriteadd(data);
					break;
				case "rewrite-getset":				//转向管理-获取转向管理详细配置
					rewriteviewset(data);
					break;
				case "rewrite-modi":				//转向管理-修改转向管理详细配置
					rewritemodi(data);
					break
				case "rewrite-del":					//转向管理-删除转向管理
					rewritedel(data);
					break;
				case "rewrite-up":					//转向管理管理-上移
					rewriteup(data);
					break;
				case "rewrite-down":				//转向管理管理-下移
					rewritedown(data);
					break;
				case "fcache-list":					//页面缓存管理-页面缓存列表
					fcachelist(data);
					break;
				case "fcache-add":					//页面缓存管理-添加页面缓存
					fcacheadd(data);
					break;
				case "fcache-getset":				//页面缓存管理-获取页面缓存详细配置
					fcacheviewset(data);
					break;
				case "fcache-modi":					//页面缓存管理-修改页面缓存详细配置
					fcachemodi(data);
					break
				case "fcache-del":					//页面缓存管理-删除页面缓存
					fcachedel(data);
					break;
				case "fcache-up":					//页面缓存管理-上移
					fcacheup(data);
					break;
				case "fcache-down":					//页面缓存管理-下移
					fcachedown(data);
					break;
				case "rcache-list":					//拒绝缓存管理-拒绝缓存列表
					rcachelist(data);
					break;
				case "rcache-add":					//拒绝缓存管理-添加拒绝缓存
					rcacheadd(data);
					break;
				case "rcache-getset":				//拒绝缓存管理-获取拒绝缓存详细配置
					rcacheviewset(data);
					break;
				case "rcache-modi":					//拒绝缓存管理-修改拒绝缓存详细配置
					rcachemodi(data);
					break
				case "rcache-del":					//拒绝缓存管理-删除拒绝缓存
					rcachedel(data);
					break;
				case "rcache-up":					//拒绝缓存管理-上移
					rcacheup(data);
					break;
				case "rcache-down":					//拒绝缓存管理-下移
					rcachedown(data);
					break;
				case "scache-list":					//会话缓存管理-会话缓存列表
					scachelist(data);
					break;
				case "scache-add":					//会话缓存管理-添加会话缓存
					scacheadd(data);
					break;
				case "scache-getset":				//会话缓存管理-获取会话缓存详细配置
					scacheviewset(data);
					break;
				case "scache-modi":					//会话缓存管理-修改会话缓存详细配置
					scachemodi(data);
					break
				case "scache-del":					//会话缓存管理-删除会话缓存
					scachedel(data);
					break;
				case "scache-up":					//会话缓存管理-上移
					scacheup(data);
					break;
				case "scache-down":					//会话缓存管理-下移
					scachedown(data);
					break;
				case "icache-clean":				//清除缓存管理-清理所有已智能缓存的页面
					icacheclean(data);
					break;
				case "fcache-clean":				//清除缓存管理-清理所有已页面缓存的页面
					fcacheclean(data);
					break;
				case "allcache-clean":				//清除缓存管理-清除所有已缓存的页面
					allcacheclean(data);
					break;
				case "scache-clean":				//清除缓存管理-清除所有已缓存的用户会话信息
					scacheclean(data);
					break;
				case "diskcache-clearindex":		//清除缓存管理-清空硬盘缓存索引
					diskcacheclearindex(data);
					break;
				case "thiscache-clean":				//清除缓存管理-按条件清除已缓存页面
					thiscacheclean(data);
					break;
				case "pass-modi":					//修改密码
					passmodi(data);
					break;
				case "rth-list":					//获取实时监控历史配置
					rthlist(data);
					break;
				case "rth-add":						//添加实时监控配置
					rthadd(data);
					break;rth-del
				case "rth-del":						//删除实时监控配置
					rthdel(data);
					break;
				case "tools-iplook":				//查询IP地址地理位置
					toolsiplook(data);
					break;	
				case "tools-testcache":				//缓存测试
					toolstestcache(data);
					break;
				case "auth-getstatus":				//获取认证状态
					authstatusget(data);
					break;
				case "auth-activate":				//激活到全功能体验版
					getauthstatus1();
					break;
				case "cluster-set":				//获得当前服务器集群内配置2011.12.29
					clustergetset(data);
					break;
				case "cluster-status":				//获得集群内服务器状态（如果是从服务器则获得连接主服务器状态）
					clustergetstatus(data);
					break;
				case "cluster-modi":				//修改本服务器集群角色（设置）
					clustermodi(data);
					break;
					
				case "diskcache-set":				//获取当前硬盘缓存设置
					diskcachelist(data);
					break;
				case "diskcache-modi":				//修改硬盘缓存设置
					diskcachemodi(data);
					break;				
				case "diskcache-open":				//获取硬盘缓存开启状态
					diskcacheopen(data);
					break;	
				case "diskcache-open-modi":			//开启、关闭硬盘缓存
					diskcacheopenmodi(data);
					break;
					
				case "diskcache-path-list":			//获取硬盘缓存目录信息
					//diskcachepathlist(data);
					//alert(ajax.responseText);
					diskcachePath.setList(data);
					break;
			}
			if(RequestID.indexOf("diskcache-path-start")!=-1){//硬盘缓存目录开启
				var id=RequestID.split("-")[3];
				diskcachePath._start(data,id);
			}
			
			if(RequestID.indexOf("diskcache-path-stop")!=-1){//硬盘缓存目录关闭
				var id=RequestID.split("-")[3];
				diskcachePath._stop(data,id);
			}
			
			if(RequestID.indexOf("diskcache-path-clear")!=-1){//硬盘缓存目录取消
				var id=RequestID.split("-")[3];
				diskcachePath.clear(data,id);
			}		

			if(RequestID.indexOf("diskcache-path-mem")!=-1){//设置硬盘缓存目录备注
				var id=RequestID.split("-")[3];
				diskcachePath.mem(data,id);
			}		
			if(RequestID.indexOf("diskcache-ssd-switch")!=-1){//切换 HDD/SSD 硬盘属性
				var id=RequestID.split("-")[3];
				diskcachePath.ModifyIsSSD_Result(data,id);
			}
			
			if(RequestID.indexOf("upstream-list")!=-1){//主机管理-源站列表
					var ProxyID=RequestID.split("-")[2];
					upstreamlist(data,ProxyID);
			}
			if(RequestID.indexOf("permit-list")!=-1){	//防盗链管理-引用链列表
					var ProtectID=RequestID.split("-")[2];
					permitlist(data,ProtectID);
			}
			if(RequestID.indexOf("rth-del")!=-1){		//删除实时监控配置
					var rthID=RequestID.split("-")[2];
					rthdel(data,rthID);
			}
		}
	} 
}

function urlencode(text){
	text = text.toString();
	var matches = text.match(/[\x90-\xFF]/g);
	if (matches)
	{
		for (var matchid = 0; matchid < matches.length; matchid++)
		{
			var char_code = matches[matchid].charCodeAt(0);
			text = text.replace(matches[matchid], '%u00' + (char_code & 0xFF).toString(16).toUpperCase());
		}
	}
	return escape(text).replace(/\+/g, "%2B");
}

function ChkKeyDown(){
	if(window.event){   
    		keynum = event.keyCode;   
	}else if(event.which){   
    		keynum = event.which;   
    	}
	if(keynum==13||keynum==32)return true;
}

function left(mainStr,lngLen) { 
	if (lngLen>0) {return mainStr.substring(0,lngLen);} 
	else{return null;} 
}
