#!/bin/sh

echo "install fikkerd service ..."

if [ ! -d "/etc/fikkerd" ]; then
    mkdir "/etc/fikkerd"
fi

pwd > "/etc/fikkerd/fikkerd.pwd"

rm -rf /etc/init.d/fikkerd
cp ../bin/fikkerd.service /etc/init.d/fikkerd

if [ -d "/etc/rc.d" ]; then
    rm -rf /etc/rc.d/rc2.d/S88fikkerd
    rm -rf /etc/rc.d/rc3.d/S88fikkerd
    rm -rf /etc/rc.d/rc4.d/S88fikkerd
    rm -rf /etc/rc.d/rc5.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc2.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc3.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc4.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc.d/rc5.d/S88fikkerd
else
    rm -rf /etc/rc2.d/S88fikkerd
    rm -rf /etc/rc3.d/S88fikkerd
    rm -rf /etc/rc4.d/S88fikkerd
    rm -rf /etc/rc5.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc2.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc3.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc4.d/S88fikkerd
    ln -s /etc/init.d/fikkerd /etc/rc5.d/S88fikkerd
fi

echo "install fikkerd service OK!"
